from django.contrib import admin
from .models import account,score
# Register your models here.
admin.site.register(account)
admin.site.register(score)